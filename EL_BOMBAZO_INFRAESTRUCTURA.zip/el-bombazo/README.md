# EL BOMBAZO by Yaxiel

Plataforma comercial PWA para una tienda que vende zapatos, chancletas, telas y otros artículos exclusivamente a domicilio.

## Estado

Incluye una interfaz administrativa navegable, módulos de operación, datos de demostración, catálogo de imágenes, manifiesto PWA, service worker, esquema PostgreSQL/Supabase con RLS inicial y documentación. La interfaz administrativa todavía utiliza estado local de demostración: no debe usarse para aceptar pagos ni operar pedidos reales hasta conectar Supabase, autenticación, funciones transaccionales y políticas revisadas.

## Requisitos

- Node.js 20.9 o superior
- npm
- Proyecto Supabase para persistencia/autenticación (opcional en modo demostración)

## Inicio local

```bash
npm install
cp .env.example .env.local
npm run dev
```

Abrir `http://localhost:3000` y `http://localhost:3000/admin`.

## Módulos del panel

Resumen, pedidos, productos, inventario, clientes, domicilios, pagos, comisiones, equipo y roles, promociones, informes, configuración y auditoría.

## Reglas comerciales de partida

- Moneda: MN.
- Venta exclusivamente a domicilio.
- Domicilio dentro de Circunvalación: 300 MN.
- Fuera de la Rotonda: consultar al administrador antes de confirmar.
- Transferencia: recargo configurable del 15%.
- Comisiones: solo el propietario administra las reglas; 1.000 MN por par de zapatos y 500 MN por tela, chancletas u otros artículos según las reglas compartidas.
- Pagos: efectivo y transferencia disponibles para todos los perfiles según el flujo de pedido.

Los importes deben confirmarse en la configuración comercial antes de operar. No se incluye integración con pasarela de pago.

## Estructura

- `src/app`: rutas y estilos globales.
- `src/components/admin`: componentes del panel por responsabilidad.
- `src/lib`: tipos y datos de demostración.
- `public/catalog`: imágenes proporcionadas para el catálogo.
- `supabase/migrations`: esquema y políticas iniciales.
- `docs`: arquitectura, guía operativa, seguridad y prompt maestro.

## Comprobación de tamaño

```bash
npm run check:lines
```

Regla del proyecto: ningún archivo de código fuente debe superar 300 líneas. Dividir componentes, servicios, esquemas y utilidades antes de ampliar un archivo.

## Seguridad antes de producción

1. Ejecutar migraciones en un proyecto Supabase de pruebas.
2. Crear usuario propietario y asignar rol desde consola segura.
3. Revisar y probar cada política RLS con usuarios de cada rol.
4. Mover creación de pedidos, cálculo de totales, descuentos, recargos, inventario y comisiones a funciones transaccionales del servidor.
5. No exponer `SUPABASE_SERVICE_ROLE_KEY` en el navegador.
6. Configurar Storage privado para comprobantes y documentos.
7. Configurar HTTPS, dominio, copias de seguridad y monitorización.
