# Seguridad y preparación de producción

- Supabase Auth: verificación de correo/teléfono, recuperación y sesiones seguras.
- RBAC: rol en tabla protegida, nunca confiar en un rol enviado desde el cliente.
- RLS: pruebas automatizadas para cada tabla y rol; denegar por defecto.
- Service role: solo variables privadas del servidor, nunca `NEXT_PUBLIC_`.
- Pedidos: crear mediante RPC transaccional; validar usuario, SKU, stock, precio, recargo, zona, cupón e idempotencia.
- Pagos: verificar manualmente transferencia; nunca guardar credenciales bancarias ni marcar como pagado desde el navegador.
- Storage: buckets privados para comprobantes, URLs firmadas y límites MIME/tamaño.
- Auditoría: registrar cambios de estado, pagos, stock, roles y comisiones.
- Datos personales: minimizar datos del repartidor; no mostrar historial de clientes a perfiles no autorizados.
- Protección: rate limit, validación Zod, CSRF donde aplique, headers seguros, logs sin secretos y backups.

La migración es una base inicial, no una certificación de seguridad. Revisar políticas con tests SQL y un proyecto de staging antes de cargar información real.
