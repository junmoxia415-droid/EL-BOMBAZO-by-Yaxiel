# Guía del panel administrativo

## Navegación

- **Resumen:** métricas, pedidos recientes y alertas.
- **Pedidos:** buscar por referencia/cliente/estado y actualizar la etapa de trabajo.
- **Productos:** alta y control de catálogo; el formulario actual añade datos a la sesión de demostración.
- **Inventario:** detectar existencias bajas; producción debe usar movimientos de inventario.
- **Clientes:** perfil, direcciones e historial.
- **Domicilios:** zonas, tarifas, asignación y seguimiento.
- **Pagos:** revisar comprobantes, referencias y conciliación.
- **Comisiones:** reglas y liquidaciones; solo el propietario puede cambiarlas.
- **Equipo y roles:** invitar, suspender y asignar permisos.
- **Promociones:** cupones, campañas y vigencia.
- **Informes:** ventas, márgenes, productos y desempeño.
- **Configuración:** reglas comerciales, moneda y canales.
- **Auditoría:** cambios sensibles y actor responsable.

## Perfiles y alcance

| Perfil | Acceso esperado |
|---|---|
| Propietario | Todo; administra reglas de comisión y permisos críticos |
| Administrador | Operación, catálogo, pedidos, pagos, logística e informes |
| Vendedor | Catálogo, pedidos propios/atribuidos y clientes necesarios |
| Repartidor | Solo entregas asignadas y datos mínimos para entregar |
| Cliente | Catálogo público, perfil y sus propios pedidos |

## Reglas comerciales

Tarifa interior de Circunvalación: 300 MN. Fuera de la Rotonda: pedir cotización al administrador. Transferencia: recargo inicial 15%. Comisión: 1.000 MN por par de zapatos y 500 MN por tela, chancletas u otros artículos. La regla exacta por cantidad/unidad debe validarse con el propietario antes de activar cálculo automático.

## Aviso

Los datos que se muestran actualmente son de demostración y se pierden al recargar. La UI no procesa dinero, no envía pedidos a una base de datos y no confirma entregas reales.
