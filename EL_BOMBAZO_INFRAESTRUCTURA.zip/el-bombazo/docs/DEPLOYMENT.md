# Despliegue a Vercel y conexión Supabase

## Preparación

1. Crear proyecto Supabase de producción y otro de staging.
2. Aplicar `supabase/migrations/0001_initial_schema.sql` en staging.
3. Crear usuario propietario desde Supabase Auth.
4. Obtener UUID del perfil y asignar rol owner usando SQL de consola segura:

```sql
insert into public.user_roles(user_id, role_id)
select '<UUID_DEL_PROPIETARIO>', id from public.roles where code='owner';
```

5. Ejecutar tests RLS con una cuenta por rol. Revisar especialmente pedidos, order_items, pagos, reparto, comisión y Storage.
6. Crear repositorio GitHub y subir el proyecto sin `.env.local` ni secretos.
7. Importar el repositorio en Vercel.
8. Configurar `NEXT_PUBLIC_SUPABASE_URL` y `NEXT_PUBLIC_SUPABASE_ANON_KEY` en Vercel para Preview y Production.
9. Configurar URL de redirección y URLs autorizadas en Supabase Auth.
10. Desplegar Preview, ejecutar pruebas y solo entonces promover a Production.

## Variables

- `NEXT_PUBLIC_SUPABASE_URL`: URL del proyecto Supabase.
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`: clave pública anon/publishable, protegida por RLS.
- `SUPABASE_SERVICE_ROLE_KEY`: únicamente para procesos server-side específicos; no se utiliza en el navegador.
- `NEXT_PUBLIC_WHATSAPP_NUMBER`: número internacional del negocio sin `+` ni espacios.

## Bloqueadores antes de producción

El panel actual no persiste productos ni pedidos y no incluye todavía RPC transaccional de checkout, conciliación real, notificaciones, ni políticas RLS probadas. No habilitar ventas reales hasta implementar y verificar esos elementos. El formulario de login requiere credenciales válidas en Supabase; sin variables, el proyecto se mantiene en modo demostración.
