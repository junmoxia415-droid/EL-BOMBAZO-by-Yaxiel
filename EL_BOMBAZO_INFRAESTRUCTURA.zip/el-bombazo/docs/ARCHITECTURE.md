# Arquitectura de EL BOMBAZO

## Visión

Aplicación PWA modular con storefront público y áreas privadas por rol. Next.js/React presenta la interfaz; Supabase Auth gestiona identidad; PostgreSQL conserva la fuente de verdad; Storage aloja imágenes y comprobantes; funciones de servidor ejecutan operaciones sensibles.

## Capas

1. Presentación: páginas, layouts, componentes reutilizables y formularios.
2. Aplicación: casos de uso para catálogo, carrito, pedido, pago, reparto, comisión y reportes.
3. Dominio: reglas de precio, zonas, estados, comisiones, inventario y permisos.
4. Infraestructura: Supabase, almacenamiento, WhatsApp deep links, analítica y exportación.

## Módulos funcionales

- Catálogo: categorías, productos, variantes, imágenes, visibilidad y precios.
- Pedidos: captura, validación, confirmación, preparación, cancelación y entrega.
- Inventario: movimientos auditables; evitar edición silenciosa del saldo.
- Clientes: perfil, direcciones, preferencias e historial propio.
- Logística: zonas, cotizaciones, asignación, aceptación y prueba de entrega.
- Pagos: efectivo y transferencia; comprobante y verificación manual.
- Comisiones: reglas editables por propietario, snapshot por línea y liquidación.
- Equipo: RBAC para owner, admin, seller, courier y customer.
- Marketing: promociones, códigos, banners y atribución.
- Analítica: ventas, ticket medio, conversión, rotación, entregas y comisiones.
- Auditoría: registro de cambios sensibles e identidad del actor.

## Flujo de pedido

Cliente crea carrito → servidor relee precios y disponibilidad → servidor cotiza zona y recargo → cliente confirma → pedido queda pendiente → pago se registra → staff verifica → pedido se prepara → reparto se asigna → repartidor acepta y entrega → se registra cierre y comisión según reglas vigentes al confirmar.

## Decisiones importantes

- Guardar dinero en unidades menores enteras (`*_minor`) y mostrar MN. Acordar escala monetaria real antes de integrar pagos.
- Mantener snapshots de nombre y precio en cada línea de pedido.
- Guardar snapshot de regla de comisión al cerrar la venta; no recalcular el pasado con reglas nuevas.
- El cliente nunca decide el total definitivo: el servidor lo calcula.
- La disponibilidad se descuenta mediante transacción, con control de concurrencia.
- WhatsApp es canal de contacto y difusión, no fuente de verdad de pedidos.

## Escalabilidad

Separar dominios en módulos; usar paginación y filtros server-side; imágenes optimizadas; índices por estado/fecha; tareas asíncronas para notificaciones; eventos idempotentes; observabilidad y backups. Extraer servicios solo cuando el volumen lo justifique, no introducir microservicios prematuramente.
