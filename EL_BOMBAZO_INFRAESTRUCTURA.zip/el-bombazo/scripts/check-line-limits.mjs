import { readdir, readFile } from "node:fs/promises";
import { join, extname } from "node:path";
const roots=["src","middleware.ts","supabase/migrations"];
const allowed=new Set([".ts",".tsx",".js",".jsx",".mjs",".css",".sql"]);
async function files(path){try{const entries=await readdir(path,{withFileTypes:true});return (await Promise.all(entries.map(entry=>{const full=join(path,entry.name);return entry.isDirectory()?files(full):[full];}))).flat();}catch{return [path];}}
const all=(await Promise.all(roots.map(files))).flat();let failed=false;
for(const file of all){if(!allowed.has(extname(file)))continue;const lines=(await readFile(file,"utf8")).split("\n").length;if(lines>300){console.error(`${file}: ${lines} líneas`);failed=true;}}
if(failed)process.exit(1);console.log("OK: ningún archivo de código supera 300 líneas.");
