import type { Metadata } from "next";
import "./globals.css";
import { PwaRegister } from "@/components/admin/pwa-register";
export const metadata: Metadata = {
  title: "EL BOMBAZO by Yaxiel | Tienda a domicilio",
  description: "Zapatos, chancletas, telas y mucho más. Compra desde casa.",
  manifest: "/manifest.webmanifest",
  themeColor: "#101014",
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="es"><body><PwaRegister />{children}</body></html>;
}
