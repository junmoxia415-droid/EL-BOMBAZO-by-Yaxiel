"use client";
import { FormEvent,useState } from "react";
import { createClient } from "@/lib/supabase/client";
export default function LoginPage(){
 const [email,setEmail]=useState("");const [password,setPassword]=useState("");const [error,setError]=useState("");const [loading,setLoading]=useState(false);
 async function submit(event:FormEvent){event.preventDefault();setLoading(true);setError("");try{const client=createClient();const {error}=await client.auth.signInWithPassword({email,password});if(error)throw error;window.location.href="/admin";}catch(e){setError(e instanceof Error?e.message:"No se pudo iniciar sesión.");}finally{setLoading(false);}}
 return <main className="landing"><form className="modal" onSubmit={submit}><div className="modal-head"><div><p className="eyebrow">EL BOMBAZO · ACCESO PRIVADO</p><h2>Iniciar sesión</h2><p className="muted">Acceso exclusivo para el equipo autorizado.</p></div></div><label>Correo electrónico<input required type="email" value={email} onChange={e=>setEmail(e.target.value)}/></label><label>Contraseña<input required type="password" value={password} onChange={e=>setPassword(e.target.value)}/></label>{error&&<p role="alert" className="error-text">{error}</p>}<button className="btn primary" disabled={loading}>{loading?"Entrando…":"Entrar al panel"}</button></form></main>;
}
