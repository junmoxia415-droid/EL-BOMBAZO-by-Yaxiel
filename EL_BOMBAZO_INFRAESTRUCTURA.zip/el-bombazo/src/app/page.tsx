import Link from "next/link";
export default function Home() {
  return <main className="landing"><div className="landing-card">
    <img src="/branding.jpg" alt="EL BOMBAZO by Yaxiel" className="brand-logo" />
    <p className="eyebrow">COMPRA FÁCIL · ENTREGA A DOMICILIO</p><h1>Lo que buscas,<br/><span>te llega a casa.</span></h1>
    <p className="muted">Zapatos, chancletas, telas y demás cositas. Descubre el catálogo y haz tu pedido sin salir de casa.</p>
    <div className="landing-actions"><Link className="btn primary" href="/admin">Entrar al panel administrativo</Link><a className="btn secondary" href="https://wa.me/" target="_blank" rel="noreferrer">Consultar por WhatsApp</a></div>
    <small>EL BOMBAZO by Yaxiel · Venta exclusivamente a domicilio</small>
  </div></main>;
}
