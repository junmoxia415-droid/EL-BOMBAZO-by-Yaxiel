"use client";
import { useMemo, useState } from "react";
import { Activity, Bell, Boxes, ChartNoAxesCombined, ChevronDown, CircleDollarSign, ClipboardList, Home, Menu, Package, Plus, Search, Settings, ShieldCheck, ShoppingBag, Truck, Users, Wallet, X } from "lucide-react";
import { initialOrders, initialProducts, money, navigation, type Order, type Product, type Section } from "@/lib/admin-data";
import { Overview } from "./overview";
import { DataSection } from "./data-section";
const icons:Record<string,typeof Home> = {dashboard:Home,orders:ClipboardList,products:Package,inventory:Boxes,customers:Users,deliveries:Truck,payments:Wallet,commissions:CircleDollarSign,team:ShieldCheck,promotions:ShoppingBag,reports:ChartNoAxesCombined,settings:Settings,audit:Activity};
export function AdminShell() {
 const [section,setSection]=useState<Section>("dashboard"); const [mobile,setMobile]=useState(false);
 const [orders,setOrders]=useState<Order[]>(initialOrders); const [products,setProducts]=useState<Product[]>(initialProducts);
 const [search,setSearch]=useState(""); const [showNew,setShowNew]=useState(false);
 const filteredOrders=useMemo(()=>orders.filter(o=>`${o.id} ${o.customer} ${o.status}`.toLowerCase().includes(search.toLowerCase())),[orders,search]);
 const updateStatus=(id:string,status:string)=>setOrders(old=>old.map(o=>o.id===id?{...o,status}:o));
 const addProduct=(product:Product)=>setProducts(old=>[product,...old]);
 const active= navigation.find(item=>item.id===section);
 return <div className="admin-layout">
  <aside className={`sidebar ${mobile?"sidebar-open":""}`}>
   <div className="side-brand"><img src="/branding.jpg" alt=""/><div><b>EL BOMBAZO</b><small>by Yaxiel · ADMIN</small></div><button className="icon-btn mobile-close" onClick={()=>setMobile(false)}><X size={18}/></button></div>
   <div className="store-switch"><span className="store-dot"/><div><b>Tienda principal</b><small>Operación activa</small></div><ChevronDown size={15}/></div>
   <nav>{[...new Set(navigation.map(n=>n.group))].map(group=><div className="nav-group" key={group}><small>{group}</small>{navigation.filter(n=>n.group===group).map(item=>{const Icon=icons[item.id];return <button key={item.id} onClick={()=>{setSection(item.id);setMobile(false);setSearch("")}} className={`nav-link ${section===item.id?"active":""}`}><Icon size={17}/><span>{item.label}</span>{"count" in item&&<em>{item.count}</em>}</button>})}</div>)}</nav>
   <div className="sidebar-bottom"><div className="help-card"><b>¿Necesitas ayuda?</b><small>Consulta la guía de administración.</small><a href="/docs/ADMIN_GUIDE.md" target="_blank">Ver documentación ↗</a></div><div className="profile-mini"><div className="avatar">Y</div><div><b>Yaxiel</b><small>Propietario</small></div><ChevronDown size={15}/></div></div>
  </aside>
  {mobile&&<button className="scrim" onClick={()=>setMobile(false)} aria-label="Cerrar menú"/>}
  <main className="main-area"><header className="topbar"><button className="icon-btn menu-toggle" onClick={()=>setMobile(true)}><Menu/></button><div className="breadcrumbs">EL BOMBAZO <span>/</span> {active?.label}</div><div className="top-actions"><span className="live-label"><i/> Tienda activa</span><button className="icon-btn notification"><Bell size={18}/><i/></button><div className="top-avatar">Y</div></div></header>
   <div className="page-content"><div className="demo-banner"><span>⚠</span><div><b>Modo de demostración</b>Los cambios se guardan solo en esta sesión. Conecta Supabase y completa la revisión de seguridad antes de procesar pedidos o pagos reales.</div></div><div className="page-heading"><div><p className="eyebrow">LUNES, 2 DE NOVIEMBRE DE 2026</p><h1>{active?.label}</h1><p className="muted">{section==="dashboard"?"Aquí tienes lo que está pasando en tu negocio.":`Gestiona ${active?.label.toLowerCase()} de EL BOMBAZO.`}</p></div>{section==="products"&&<button className="btn primary" onClick={()=>setShowNew(true)}><Plus size={17}/> Nuevo producto</button>}</div>
    {section==="dashboard"?<Overview orders={orders} products={products} onNavigate={setSection}/>:<DataSection section={section} orders={filteredOrders} products={products} search={search} setSearch={setSearch} updateStatus={updateStatus} onAddProduct={addProduct} />}
   </div>
  </main>
  {showNew&&<ProductModal onClose={()=>setShowNew(false)} onSave={p=>{addProduct(p);setShowNew(false)}}/>}
 </div>;
}
function ProductModal({onClose,onSave}:{onClose:()=>void;onSave:(p:Product)=>void}){
 const [name,setName]=useState("");const [category,setCategory]=useState("Zapatos");const [price,setPrice]=useState("0");const [stock,setStock]=useState("0");
 return <div className="modal-backdrop" onMouseDown={onClose}><form className="modal" onSubmit={e=>{e.preventDefault();onSave({id:`P-${Date.now()}`,name,category,price:Number(price),stock:Number(stock),status:"Borrador",image:""})}} onMouseDown={e=>e.stopPropagation()}><div className="modal-head"><div><h2>Crear producto</h2><p className="muted">Añade un artículo al catálogo.</p></div><button type="button" className="icon-btn" onClick={onClose}><X/></button></div><label>Nombre del producto<input required value={name} onChange={e=>setName(e.target.value)} placeholder="Ej. Zapato casual"/></label><div className="form-row"><label>Categoría<select value={category} onChange={e=>setCategory(e.target.value)}><option>Zapatos</option><option>Chancletas</option><option>Telas</option><option>Otros</option></select></label><label>Precio (MN)<input type="number" min="0" value={price} onChange={e=>setPrice(e.target.value)}/></label></div><label>Existencias<input type="number" min="0" value={stock} onChange={e=>setStock(e.target.value)}/></label><div className="modal-actions"><button type="button" className="btn secondary" onClick={onClose}>Cancelar</button><button className="btn primary">Guardar producto</button></div></form></div>;
}
