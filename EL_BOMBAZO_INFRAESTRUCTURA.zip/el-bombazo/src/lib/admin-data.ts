export type Section = "dashboard" | "orders" | "products" | "inventory" | "customers" | "deliveries" | "payments" | "commissions" | "team" | "promotions" | "reports" | "settings" | "audit";
export type Order = { id:string; customer:string; items:string; total:number; status:string; date:string; delivery:string };
export type Product = { id:string; name:string; category:string; price:number; stock:number; status:string; image:string };
export const navigation = [
 {id:"dashboard",label:"Resumen",group:"GENERAL"}, {id:"orders",label:"Pedidos",group:"VENTAS",count:5},
 {id:"products",label:"Productos",group:"CATÁLOGO"}, {id:"inventory",label:"Inventario",group:"CATÁLOGO"},
 {id:"customers",label:"Clientes",group:"VENTAS"}, {id:"deliveries",label:"Domicilios",group:"OPERACIONES"},
 {id:"payments",label:"Pagos",group:"OPERACIONES"}, {id:"commissions",label:"Comisiones",group:"FINANZAS"},
 {id:"team",label:"Equipo y roles",group:"NEGOCIO"}, {id:"promotions",label:"Promociones",group:"MARKETING"},
 {id:"reports",label:"Informes",group:"ANÁLISIS"}, {id:"settings",label:"Configuración",group:"SISTEMA"},
 {id:"audit",label:"Auditoría",group:"SISTEMA"},
] as const;
export const initialOrders:Order[] = [
 {id:"BZ-2048",customer:"María González",items:"2 pares de zapatos",total:5400,status:"Pendiente",date:"Hoy · 10:42",delivery:"Circunvalación"},
 {id:"BZ-2047",customer:"Carlos Pérez",items:"Tela estampada × 4 m",total:3200,status:"Confirmado",date:"Hoy · 09:18",delivery:"Fuera de zona"},
 {id:"BZ-2046",customer:"Ana Rodríguez",items:"Chancletas × 2",total:1800,status:"En reparto",date:"Ayer · 18:30",delivery:"Circunvalación"},
 {id:"BZ-2045",customer:"Luis Martínez",items:"Zapatos deportivos",total:4200,status:"Entregado",date:"Ayer · 16:12",delivery:"Circunvalación"},
 {id:"BZ-2044",customer:"Sofía Díaz",items:"Tela + chancletas",total:2700,status:"Entregado",date:"Ayer · 12:05",delivery:"Cotizar zona"},
];
export const initialProducts:Product[] = [
 {id:"P-001",name:"Zapato casual urbano",category:"Zapatos",price:4500,stock:12,status:"Publicado",image:"/catalog/WhatsApp Image 2026-11-02 at 4.29.59 AM.jpeg"},
 {id:"P-002",name:"Chancleta clásica",category:"Chancletas",price:850,stock:28,status:"Publicado",image:"/catalog/WhatsApp Image 2026-11-02 at 4.29.59 AM (1).jpeg"},
 {id:"P-003",name:"Tela estampada",category:"Telas",price:700,stock:45,status:"Publicado",image:"/catalog/WhatsApp Image 2026-11-02 at 4.29.59 AM (2).jpeg"},
 {id:"P-004",name:"Zapato deportivo",category:"Zapatos",price:5200,stock:3,status:"Publicado",image:"/catalog/WhatsApp Image 2026-11-02 at 4.29.58 AM.jpeg"},
];
export const money = (value:number) => new Intl.NumberFormat("es-ES",{maximumFractionDigits:0}).format(value)+" MN";
